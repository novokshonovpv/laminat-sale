function assetRequest(request, pathname) {
  const url = new URL(request.url);
  url.pathname = pathname;
  return new Request(url, request);
}

const productSelect = `
  SELECT
    id, slug, model, name, brand, collection,
    load_class AS class, thickness, dimensions,
    package_area AS packageArea, pieces_per_package AS piecesPerPackage,
    price_per_square_meter AS pricePerSquareMeter, vat_percent AS vatPercent,
    stock_square_meters AS stockSquareMeters, color, image, description, badge,
    compare_at_price AS compareAtPrice, order_lead_days AS orderLeadDays,
    is_visible AS isVisible, updated_at AS updatedAt
  FROM products`;

function json(data, status = 200) {
  return Response.json(data, { status, headers: { "cache-control": "no-store", "x-content-type-options": "nosniff" } });
}

function isAdmin(request, env) {
  const userId = request.headers.get("oai-authenticated-user-id");
  const email = request.headers.get("oai-authenticated-user-email")?.toLocaleLowerCase("ru-RU");
  return Boolean(
    (env.ADMIN_USER_ID && userId === env.ADMIN_USER_ID) ||
    (env.ADMIN_EMAIL && email === String(env.ADMIN_EMAIL).toLocaleLowerCase("ru-RU")),
  );
}

async function listProducts(env, includeHidden = false) {
  const where = includeHidden ? "" : " WHERE is_visible = 1";
  const { results } = await env.DB.prepare(`${productSelect}${where} ORDER BY model COLLATE NOCASE`).all();
  return results;
}

function detectImageType(bytes) {
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return { contentType: "image/jpeg", extension: "jpg" };
  if (bytes.length >= 8 && [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a].every((value, index) => bytes[index] === value)) return { contentType: "image/png", extension: "png" };
  if (bytes.length >= 12 && String.fromCharCode(...bytes.slice(0, 4)) === "RIFF" && String.fromCharCode(...bytes.slice(8, 12)) === "WEBP") return { contentType: "image/webp", extension: "webp" };
  return null;
}

async function serveProductImage(env, url) {
  if (!env.PRODUCT_IMAGES) return new Response("Хранилище изображений недоступно", { status: 503 });
  const encodedKey = url.pathname.slice("/media/products/".length);
  let filename;
  try { filename = decodeURIComponent(encodedKey); } catch { return new Response("Изображение не найдено", { status: 404 }); }
  if (!/^[a-z0-9-]+\.(jpg|png|webp)$/.test(filename)) return new Response("Изображение не найдено", { status: 404 });
  const key = `products/${filename}`;
  const object = await env.PRODUCT_IMAGES.get(key);
  if (!object) return new Response("Изображение не найдено", { status: 404 });
  return new Response(object.body, {
    headers: {
      "content-type": object.httpMetadata?.contentType || "application/octet-stream",
      "cache-control": "public, max-age=31536000, immutable",
      etag: object.httpEtag,
      "x-content-type-options": "nosniff",
    },
  });
}

async function uploadProductImage(request, env, productId) {
  if (!env.PRODUCT_IMAGES) return json({ error: "Хранилище изображений не подключено" }, 503);
  const contentLength = Number(request.headers.get("content-length") ?? 0);
  if (contentLength > 8_500_000) return json({ error: "Файл слишком большой. Максимум 8 МБ." }, 413);

  const current = await env.DB.prepare(`${productSelect} WHERE id = ?`).bind(productId).first();
  if (!current) return json({ error: "Товар не найден" }, 404);

  let form;
  try { form = await request.formData(); } catch { return json({ error: "Не удалось прочитать файл" }, 400); }
  const file = form.get("image");
  if (!file || typeof file.arrayBuffer !== "function") return json({ error: "Выберите изображение" }, 400);
  if (file.size < 100 || file.size > 8_000_000) return json({ error: "Допустимый размер файла — до 8 МБ" }, 400);

  const data = await file.arrayBuffer();
  const type = detectImageType(new Uint8Array(data, 0, Math.min(data.byteLength, 16)));
  if (!type) return json({ error: "Поддерживаются JPEG, PNG и WebP" }, 400);

  const safeId = productId.toLocaleLowerCase("en-US").replace(/[^a-z0-9-]/g, "-");
  const filename = `${safeId}-${crypto.randomUUID()}.${type.extension}`;
  const key = `products/${filename}`;
  await env.PRODUCT_IMAGES.put(key, data, { httpMetadata: { contentType: type.contentType }, customMetadata: { productId } });

  const image = `/media/products/${filename}`;
  const result = await env.DB.prepare("UPDATE products SET image = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?").bind(image, productId).run();
  if (!result.meta?.changes) {
    await env.PRODUCT_IMAGES.delete(key);
    return json({ error: "Не удалось обновить товар" }, 500);
  }
  const product = await env.DB.prepare(`${productSelect} WHERE id = ?`).bind(productId).first();
  return json({ product }, 201);
}

const cleanText = (value, max) => String(value ?? "").trim().replace(/\s+/g, " ").slice(0, max);
const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" })[character]);

async function sendOrderEmail(env, orderId) {
  const order = await env.DB.prepare("SELECT * FROM orders WHERE id = ?").bind(orderId).first();
  if (!order) return "failed";
  if (!env.RESEND_API_KEY || !env.ORDER_NOTIFICATION_EMAIL || !env.ORDER_EMAIL_FROM) {
    await env.DB.prepare("UPDATE orders SET notification_status = 'not_configured', notification_error = 'Почтовый сервис не настроен', updated_at = CURRENT_TIMESTAMP WHERE id = ?").bind(orderId).run();
    return "not_configured";
  }

  const html = `<div style="font-family:Arial,sans-serif;color:#2f2a24"><h1>Новый заказ ${escapeHtml(order.id)}</h1><p>На сайте оформлен новый заказ. Контактные данные и состав заказа доступны только в закрытой панели владельца.</p><p><a href="https://laminat-sale-smolensk.pavelnovokshonov.chatgpt.site/admin/orders/">Открыть заказы</a></p></div>`;

  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { authorization: `Bearer ${env.RESEND_API_KEY}`, "content-type": "application/json", "user-agent": "laminat-sale/1.0", "idempotency-key": `order-${order.id}` },
      body: JSON.stringify({ from: env.ORDER_EMAIL_FROM, to: [env.ORDER_NOTIFICATION_EMAIL], subject: `Новый заказ ${order.id}`, html }),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.message || `Resend: ${response.status}`);
    await env.DB.prepare("UPDATE orders SET notification_status = 'sent', notification_id = ?, notification_error = NULL, updated_at = CURRENT_TIMESTAMP WHERE id = ?").bind(data.id ?? null, orderId).run();
    return "sent";
  } catch (error) {
    await env.DB.prepare("UPDATE orders SET notification_status = 'failed', notification_error = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?").bind(cleanText(error instanceof Error ? error.message : "Ошибка отправки", 500), orderId).run();
    return "failed";
  }
}

async function createOrder(request, env) {
  if (Number(request.headers.get("content-length") ?? 0) > 30_000) return json({ error: "Слишком большой запрос" }, 413);
  let payload;
  try { payload = await request.json(); } catch { return json({ error: "Некорректные данные" }, 400); }
  if (payload.website) return json({ error: "Заказ не принят" }, 400);

  const name = cleanText(payload.name, 100);
  const phone = cleanText(payload.phone, 40);
  const email = cleanText(payload.email, 160).toLocaleLowerCase("ru-RU");
  const comment = cleanText(payload.comment, 1000);
  const deliveryMethod = payload.deliveryMethod === "pickup" ? "pickup" : payload.deliveryMethod === "delivery" ? "delivery" : null;
  if (name.length < 2) return json({ error: "Укажите имя" }, 400);
  if (phone.replace(/\D/g, "").length < 10) return json({ error: "Проверьте телефон" }, 400);
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json({ error: "Проверьте email" }, 400);
  if (!deliveryMethod) return json({ error: "Выберите способ получения" }, 400);
  if (payload.consent !== true) return json({ error: "Нужно согласие на обработку данных" }, 400);
  if (!Array.isArray(payload.items) || payload.items.length < 1 || payload.items.length > 20) return json({ error: "Корзина пуста или содержит слишком много позиций" }, 400);

  const requested = [];
  for (const item of payload.items) {
    const productId = cleanText(item.productId, 100);
    const packages = Number(item.packages);
    if (!productId || !Number.isInteger(packages) || packages < 1 || packages > 999) return json({ error: "Проверьте количество упаковок" }, 400);
    requested.push({ productId, packages });
  }

  const results = await env.DB.batch(requested.map((item) => env.DB.prepare(`${productSelect} WHERE id = ? AND is_visible = 1`).bind(item.productId)));
  const lines = requested.map((item, index) => {
    const product = results[index]?.results?.[0];
    if (!product) return null;
    const area = Math.round(item.packages * Number(product.packageArea) * 100) / 100;
    const subtotal = product.pricePerSquareMeter == null ? null : Math.round(area * Number(product.pricePerSquareMeter));
    return { productId: product.id, model: product.model, name: product.name, packages: item.packages, packageArea: Number(product.packageArea), area, pricePerSquareMeter: product.pricePerSquareMeter, subtotal };
  });
  if (lines.some((line) => line === null)) return json({ error: "Один из товаров больше недоступен. Обновите корзину." }, 409);

  const orderLines = lines.filter(Boolean);
  const totalArea = Math.round(orderLines.reduce((sum, item) => sum + item.area, 0) * 100) / 100;
  const hasRequestPrice = orderLines.some((item) => item.subtotal == null);
  const totalPrice = hasRequestPrice ? null : orderLines.reduce((sum, item) => sum + item.subtotal, 0);
  const date = new Date().toISOString().slice(0, 10).replaceAll("-", "");
  const orderId = `LS-${date}-${crypto.randomUUID().slice(0, 6).toUpperCase()}`;
  const statements = [
    env.DB.prepare("INSERT INTO orders (id, customer_name, customer_phone, customer_email, comment, delivery_method, item_count, total_area, total_price, has_request_price, items_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)").bind(orderId, name, phone, email || null, comment || null, deliveryMethod, orderLines.length, totalArea, totalPrice, hasRequestPrice ? 1 : 0, JSON.stringify(orderLines)),
    ...orderLines.map((item) => env.DB.prepare("INSERT INTO order_items (order_id, product_id, model, name, packages, package_area, area, price_per_square_meter, subtotal) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)").bind(orderId, item.productId, item.model, item.name, item.packages, item.packageArea, item.area, item.pricePerSquareMeter, item.subtotal)),
  ];
  await env.DB.batch(statements);
  const notificationStatus = await sendOrderEmail(env, orderId);
  return json({ orderId, notificationStatus }, 201);
}

async function handleApi(request, env, url) {
  if (!env.DB) return json({ error: "Каталог временно недоступен" }, 503);

  if (url.pathname === "/api/catalog" && request.method === "GET") return json({ products: await listProducts(env) });

  if (url.pathname === "/api/orders" && request.method === "POST") return createOrder(request, env);

  const publicProduct = url.pathname.match(/^\/api\/catalog\/([^/]+)$/);
  if (publicProduct && request.method === "GET") {
    const row = await env.DB.prepare(`${productSelect} WHERE id = ? AND is_visible = 1`).bind(decodeURIComponent(publicProduct[1])).first();
    return row ? json({ product: row }) : json({ error: "Товар не найден" }, 404);
  }

  if (!url.pathname.startsWith("/api/admin/")) return json({ error: "Маршрут не найден" }, 404);
  if (!isAdmin(request, env)) return json({ error: "Доступ разрешён только владельцу магазина" }, 403);
  if (url.pathname === "/api/admin/products" && request.method === "GET") return json({ products: await listProducts(env, true) });

  const adminProductImage = url.pathname.match(/^\/api\/admin\/products\/([^/]+)\/image$/);
  if (adminProductImage && request.method === "POST") return uploadProductImage(request, env, decodeURIComponent(adminProductImage[1]));

  if (url.pathname === "/api/admin/orders" && request.method === "GET") {
    const { results } = await env.DB.prepare("SELECT id, customer_name AS customerName, customer_phone AS customerPhone, customer_email AS customerEmail, comment, delivery_method AS deliveryMethod, status, item_count AS itemCount, total_area AS totalArea, total_price AS totalPrice, has_request_price AS hasRequestPrice, items_json AS itemsJson, notification_status AS notificationStatus, notification_error AS notificationError, created_at AS createdAt, updated_at AS updatedAt FROM orders ORDER BY created_at DESC LIMIT 100").all();
    return json({ orders: results.map((order) => ({ ...order, items: JSON.parse(order.itemsJson), itemsJson: undefined })) });
  }

  const adminOrderNotify = url.pathname.match(/^\/api\/admin\/orders\/([^/]+)\/notify$/);
  if (adminOrderNotify && request.method === "POST") return json({ notificationStatus: await sendOrderEmail(env, decodeURIComponent(adminOrderNotify[1])) });

  const adminOrder = url.pathname.match(/^\/api\/admin\/orders\/([^/]+)$/);
  if (adminOrder && request.method === "PATCH") {
    let payload;
    try { payload = await request.json(); } catch { return json({ error: "Некорректные данные" }, 400); }
    const allowed = new Set(["new", "confirmed", "completed", "cancelled"]);
    if (!allowed.has(payload.status)) return json({ error: "Некорректный статус" }, 400);
    const result = await env.DB.prepare("UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?").bind(payload.status, decodeURIComponent(adminOrder[1])).run();
    return result.meta?.changes ? json({ ok: true }) : json({ error: "Заказ не найден" }, 404);
  }

  const adminProduct = url.pathname.match(/^\/api\/admin\/products\/([^/]+)$/);
  if (adminProduct && request.method === "PATCH") {
    if (Number(request.headers.get("content-length") ?? 0) > 10_000) return json({ error: "Слишком большой запрос" }, 413);
    let payload;
    try { payload = await request.json(); } catch { return json({ error: "Некорректные данные" }, 400); }

    const price = payload.pricePerSquareMeter === null || payload.pricePerSquareMeter === "" ? null : Number(payload.pricePerSquareMeter);
    const stock = Number(payload.stockSquareMeters);
    const visible = payload.isVisible === true || payload.isVisible === 1 ? 1 : payload.isVisible === false || payload.isVisible === 0 ? 0 : null;
    if (price !== null && (!Number.isInteger(price) || price < 0 || price > 10_000_000)) return json({ error: "Проверьте цену" }, 400);
    if (!Number.isFinite(stock) || stock < 0 || stock > 1_000_000) return json({ error: "Проверьте остаток" }, 400);
    if (visible === null) return json({ error: "Проверьте видимость товара" }, 400);

    const id = decodeURIComponent(adminProduct[1]);
    const result = await env.DB.prepare(`UPDATE products SET price_per_square_meter = ?, vat_percent = CASE WHEN ? IS NOT NULL THEN COALESCE(vat_percent, 22) ELSE vat_percent END, stock_square_meters = ?, is_visible = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`).bind(price, price, stock, visible, id).run();
    if (!result.meta?.changes) return json({ error: "Товар не найден" }, 404);
    const row = await env.DB.prepare(`${productSelect} WHERE id = ?`).bind(id).first();
    return json({ product: row });
  }
  return json({ error: "Метод не поддерживается" }, 405);
}

async function sitemap(env, origin) {
  if (!env.DB) return null;
  const { results } = await env.DB.prepare("SELECT slug, updated_at AS updatedAt FROM products WHERE is_visible = 1 ORDER BY model COLLATE NOCASE").all();
  const fixed = ["", "/catalog/", "/cart/", "/privacy/", "/personal-data-consent/"];
  const entries = [
    ...fixed.map((path) => `<url><loc>${origin}${path}</loc></url>`),
    ...results.map((row) => `<url><loc>${origin}/product/${row.slug}/</loc><lastmod>${String(row.updatedAt).slice(0, 10)}</lastmod></url>`),
  ];
  return new Response(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${entries.join("")}</urlset>`, {
    headers: { "content-type": "application/xml; charset=utf-8", "cache-control": "public, max-age=300" },
  });
}

const worker = {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "GET" && url.pathname.startsWith("/media/products/")) return serveProductImage(env, url);
    if (url.pathname.startsWith("/api/")) return handleApi(request, env, url);

    if ((url.pathname === "/admin" || url.pathname.startsWith("/admin/")) && !isAdmin(request, env)) {
      return new Response("Доступ к управлению каталогом разрешён только владельцу магазина.", { status: 403, headers: { "content-type": "text/plain; charset=utf-8", "cache-control": "no-store" } });
    }

    if (url.pathname === "/sitemap.xml") {
      const response = await sitemap(env, url.origin);
      if (response) return response;
    }

    const productRoute = url.pathname.match(/^\/product\/([^/]+)\/?$/);
    if (productRoute && env.DB) {
      const row = await env.DB.prepare("SELECT is_visible AS isVisible FROM products WHERE slug = ?").bind(decodeURIComponent(productRoute[1])).first();
      if (row && row.isVisible === 0) return new Response("Товар не найден", { status: 404 });
    }

    const direct = await env.ASSETS.fetch(request);
    if (direct.status !== 404 || url.pathname.includes(".")) return direct;
    const cleanPath = url.pathname.replace(/\/$/, "") || "/index";
    const html = await env.ASSETS.fetch(assetRequest(request, `${cleanPath}.html`));
    if (html.status !== 404) return html;
    return env.ASSETS.fetch(assetRequest(request, `${cleanPath}/index.html`));
  },
};

export default worker;
