import type { Metadata } from "next";
import { OrdersAdmin } from "@/components/orders-admin";

export const metadata: Metadata = { title: "Заказы", robots: { index: false, follow: false } };

export default function OrdersPage() {
  return <OrdersAdmin />;
}
