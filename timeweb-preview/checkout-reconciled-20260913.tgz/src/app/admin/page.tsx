import type { Metadata } from "next";
import { CatalogAdmin } from "@/components/catalog-admin";

export const metadata: Metadata = {
  title: "Управление каталогом",
  robots: { index: false, follow: false },
};

export default function AdminPage() {
  return <CatalogAdmin />;
}
