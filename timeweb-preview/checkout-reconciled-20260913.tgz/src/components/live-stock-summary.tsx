"use client";

import { useEffect, useState } from "react";
import type { Product } from "@/data/products";

export function LiveStockSummary() {
  const [summary, setSummary] = useState("6 моделей в наличии · склад в Смоленске");

  useEffect(() => {
    fetch("/api/catalog", { headers: { accept: "application/json" } })
      .then((response) => response.ok ? response.json() : Promise.reject())
      .then((data: { products?: Product[] }) => {
        if (!Array.isArray(data.products)) return;
        const stocked = data.products.filter((item) => item.stockSquareMeters > 0);
        setSummary(`${stocked.length} ${stocked.length === 1 ? "модель" : stocked.length < 5 ? "модели" : "моделей"} в наличии · склад в Смоленске`);
      })
      .catch(() => {});
  }, []);

  return <span className="absolute right-5 top-5 rounded-full bg-[#54704b] px-4 py-2 text-xs font-semibold text-white shadow-sm sm:right-6 sm:top-6">{summary}</span>;
}
