"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { formatPrice } from "@/data/products";

type OrderLine = { productId: string; model: string; name: string; packages: number; area: number; subtotal: number | null };
type Order = { id: string; customerName: string; customerPhone: string; customerEmail?: string; comment?: string; deliveryMethod: "pickup" | "delivery"; status: "new" | "confirmed" | "completed" | "cancelled"; itemCount: number; totalArea: number; totalPrice: number | null; items: OrderLine[]; notificationStatus: "pending" | "sent" | "failed" | "not_configured"; notificationError?: string; createdAt: string };

const statusLabels = { new: "Новый", confirmed: "Подтверждён", completed: "Завершён", cancelled: "Отменён" };
const notificationLabels = { pending: "Отправляется", sent: "Письмо отправлено", failed: "Ошибка письма", not_configured: "Почта не настроена" };

export function OrdersAdmin() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState("");

  async function load() {
    setError("");
    try {
      const response = await fetch("/api/admin/orders", { headers: { accept: "application/json" } });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Не удалось загрузить заказы");
      setOrders(data.orders);
    } catch (caught) { setError(caught instanceof Error ? caught.message : "Ошибка загрузки"); }
    finally { setLoading(false); }
  }

  useEffect(() => { load(); }, []);

  async function updateStatus(order: Order, status: Order["status"]) {
    setBusy(order.id);
    setError("");
    try {
    const response = await fetch(`/api/admin/orders/${encodeURIComponent(order.id)}`, { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ status }) });
    if (!response.ok) throw new Error("Статус не сохранён. Повторите попытку.");
    setOrders((current) => current.map((item) => item.id === order.id ? { ...item, status } : item));
    } catch (caught) { setError(caught instanceof Error ? caught.message : "Ошибка сохранения"); }
    finally { setBusy(""); }
  }

  async function retryNotification(order: Order) {
    setBusy(order.id);
    try {
    await fetch(`/api/admin/orders/${encodeURIComponent(order.id)}/notify`, { method: "POST" });
    await load();
    } catch { setError("Не удалось отправить уведомление"); }
    finally { setBusy(""); }
  }

  return <div className="mx-auto max-w-[1200px] px-5 py-10 sm:px-8 lg:px-12">
    <div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between"><div><p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#8b5e3c]">Закрытый раздел владельца</p><h1 className="mt-3 text-4xl font-semibold tracking-[-0.05em] sm:text-5xl">Заказы</h1><p className="mt-4 text-sm text-[#756a5f]">Последние 100 заявок с сайта и статус email-уведомления.</p></div><Link href="/admin" className="inline-flex min-h-11 items-center justify-center rounded-full border border-[#b9a792] px-6 text-sm font-semibold text-[#60452f]">← Каталог</Link></div>
    {loading && <div className="mt-8 rounded-3xl border border-[#d3c5b4] p-10 text-center">Загружаем заказы…</div>}
    {error && <div className="mt-8 rounded-3xl bg-[#f8e2dc] p-5 text-[#8b3f2c]" role="alert">{error}</div>}
    {!loading && !error && orders.length === 0 && <div className="mt-8 rounded-3xl border border-dashed border-[#cfc0ad] bg-[#fbf8f2] p-12 text-center"><h2 className="text-2xl font-semibold">Заказов пока нет</h2><p className="mt-2 text-sm text-[#756a5f]">Новые заявки появятся здесь сразу после оформления.</p></div>}
    <section className="mt-8 space-y-5">
      {orders.map((order) => <article key={order.id} className="rounded-3xl border border-[#d3c5b4] bg-[#fbf8f2] p-5 sm:p-7">
        <div className="flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between"><div><div className="flex flex-wrap items-center gap-2"><h2 className="text-xl font-semibold">{order.id}</h2><span className="rounded-full bg-[#eadbc7] px-3 py-1 text-xs font-semibold">{statusLabels[order.status]}</span><span className={`rounded-full px-3 py-1 text-xs font-semibold ${order.notificationStatus === "sent" ? "bg-[#e4ecde] text-[#47603f]" : "bg-[#f4e5dc] text-[#8b4d36]"}`}>{notificationLabels[order.notificationStatus]}</span></div><p className="mt-2 text-xs text-[#817469]">{new Date(order.createdAt.replace(" ", "T") + "Z").toLocaleString("ru-RU")}</p><p className="mt-4 text-sm"><strong>{order.customerName}</strong> · <a href={`tel:${order.customerPhone}`} className="text-[#71482e]">{order.customerPhone}</a>{order.customerEmail && <> · <a href={`mailto:${order.customerEmail}`} className="text-[#71482e]">{order.customerEmail}</a></>}</p><p className="mt-2 text-sm text-[#756a5f]">{order.deliveryMethod === "pickup" ? "Самовывоз" : "Доставка"}{order.comment ? ` · ${order.comment}` : ""}</p></div><div className="lg:text-right"><strong className="text-2xl">{order.totalPrice == null ? "Цена по запросу" : `${formatPrice(Number(order.totalPrice))} ₽`}</strong><p className="mt-1 text-sm text-[#756a5f]">{order.itemCount} поз. · {order.totalArea.toLocaleString("ru-RU")} м²</p></div></div>
        <details className="mt-5 rounded-2xl border border-[#ded3c5] bg-white/60 p-4"><summary className="cursor-pointer text-sm font-semibold">Состав заказа</summary><div className="mt-4 space-y-3">{order.items.map((item) => <div key={item.productId} className="flex flex-col justify-between gap-1 border-t border-[#e5dbcc] pt-3 text-sm sm:flex-row"><span>SPC {item.model} — {item.name}</span><span>{item.packages} уп. · {item.area} м² · {item.subtotal == null ? "по запросу" : `${formatPrice(item.subtotal)} ₽`}</span></div>)}</div></details>
        <div className="mt-5 flex flex-wrap gap-3"><select value={order.status} onChange={(event) => updateStatus(order, event.target.value as Order["status"])} disabled={busy === order.id} className="min-h-11 rounded-full border border-[#c9b9a5] bg-white px-4 text-sm"><option value="new">Новый</option><option value="confirmed">Подтверждён</option><option value="completed">Завершён</option><option value="cancelled">Отменён</option></select>{order.notificationStatus === "failed" && <button disabled={busy === order.id} onClick={() => retryNotification(order)} className="min-h-11 rounded-full bg-[#71482e] px-5 text-sm font-semibold text-white disabled:opacity-60">Повторить отправку email</button>}</div>
        {order.notificationError && <p className="mt-3 text-xs text-[#8b4d36]">{order.notificationError}</p>}
      </article>)}
    </section>
  </div>;
}
