"use client";

import { useEffect, useMemo, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { assetPath } from "@/lib/asset-path";
import { formatPrice, getProductSlug, type Product } from "@/data/products";

type AdminProduct = Product & { isVisible: number; updatedAt: string };
type SaveState = { id: string; kind: "saving" | "saved" | "error"; message?: string } | null;
type UploadState = { id: string; kind: "uploading" | "saved" | "error"; message?: string } | null;

export function CatalogAdmin() {
  const [products, setProducts] = useState<AdminProduct[]>([]);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [saveState, setSaveState] = useState<SaveState>(null);
  const [uploadState, setUploadState] = useState<UploadState>(null);

  useEffect(() => {
    fetch("/api/admin/products", { headers: { accept: "application/json" } })
      .then(async (response) => {
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Не удалось загрузить каталог");
        return data;
      })
      .then((data: { products: AdminProduct[] }) => setProducts(data.products))
      .catch((error: Error) => setLoadError(error.message))
      .finally(() => setLoading(false));
  }, []);

  const filtered = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase("ru-RU");
    return products.filter((item) => !normalized || [item.model, item.name, item.collection].some((value) => value.toLocaleLowerCase("ru-RU").includes(normalized)));
  }, [products, query]);

  const visibleCount = products.filter((item) => item.isVisible === 1).length;
  const stockCount = products.filter((item) => item.stockSquareMeters > 0).length;

  function update(id: string, changes: Partial<AdminProduct>) {
    setProducts((current) => current.map((item) => item.id === id ? { ...item, ...changes } : item));
    if (saveState?.id === id) setSaveState(null);
  }

  async function save(item: AdminProduct) {
    setSaveState({ id: item.id, kind: "saving" });
    try {
      const response = await fetch(`/api/admin/products/${encodeURIComponent(item.id)}`, {
        method: "PATCH",
        headers: { "content-type": "application/json", accept: "application/json" },
        body: JSON.stringify({
          pricePerSquareMeter: item.pricePerSquareMeter ?? null,
          stockSquareMeters: item.stockSquareMeters,
          isVisible: item.isVisible === 1,
        }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Не удалось сохранить изменения");
      setProducts((current) => current.map((product) => product.id === item.id ? data.product : product));
      setSaveState({ id: item.id, kind: "saved" });
    } catch (error) {
      setSaveState({ id: item.id, kind: "error", message: error instanceof Error ? error.message : "Ошибка сохранения" });
    }
  }

  async function uploadImage(item: AdminProduct, file: File) {
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
      setUploadState({ id: item.id, kind: "error", message: "Нужен JPEG, PNG или WebP" });
      return;
    }
    if (file.size > 8_000_000) {
      setUploadState({ id: item.id, kind: "error", message: "Максимум 8 МБ" });
      return;
    }

    setUploadState({ id: item.id, kind: "uploading" });
    const form = new FormData();
    form.append("image", file);
    try {
      const response = await fetch(`/api/admin/products/${encodeURIComponent(item.id)}/image`, { method: "POST", body: form, headers: { accept: "application/json" } });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Не удалось загрузить изображение");
      setProducts((current) => current.map((product) => product.id === item.id ? data.product : product));
      setUploadState({ id: item.id, kind: "saved" });
    } catch (error) {
      setUploadState({ id: item.id, kind: "error", message: error instanceof Error ? error.message : "Ошибка загрузки" });
    }
  }

  return (
    <div className="mx-auto max-w-[1440px] px-5 py-10 sm:px-8 lg:px-12">
      <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
        <div><p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#8b5e3c]">Закрытый раздел владельца</p><h1 className="mt-3 text-4xl font-semibold tracking-[-0.05em] sm:text-5xl">Управление каталогом</h1><p className="mt-4 max-w-2xl text-sm leading-6 text-[#756a5f]">Меняйте изображение, цену, остаток и видимость товара. Каталог обновляется без новой публикации сайта.</p></div>
        <div className="flex flex-wrap gap-3"><Link href="/admin/orders" className="inline-flex min-h-11 items-center justify-center rounded-full bg-[#71482e] px-6 text-sm font-semibold text-white">Заказы →</Link><Link href="/catalog" className="inline-flex min-h-11 items-center justify-center rounded-full border border-[#b9a792] px-6 text-sm font-semibold text-[#60452f]">Открыть каталог →</Link></div>
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        <Summary label="Всего товаров" value={products.length} />
        <Summary label="Показываются" value={visibleCount} />
        <Summary label="Есть на складе" value={stockCount} />
      </div>

      <div className="mt-8 rounded-3xl border border-[#d3c5b4] bg-[#fbf8f2] p-5 sm:p-6">
        <label className="block text-sm font-semibold" htmlFor="admin-search">Поиск по модели или названию</label>
        <input id="admin-search" value={query} onChange={(event) => setQuery(event.target.value)} type="search" placeholder="Например, 804 или дуб медовый" className="mt-2 min-h-12 w-full rounded-xl border border-[#c9b9a5] bg-white px-4 outline-none focus:border-[#71482e]" />
      </div>

      {loading && <div className="mt-8 rounded-3xl border border-[#d3c5b4] bg-[#fbf8f2] p-10 text-center text-[#756a5f]">Загружаем каталог…</div>}
      {loadError && <div className="mt-8 rounded-3xl border border-[#c78f7c] bg-[#f8e9e2] p-6 text-[#7b3f2d]" role="alert"><strong>Каталог не загружен.</strong><p className="mt-1 text-sm">{loadError}</p></div>}

      {!loading && !loadError && (
        <section className="mt-8 space-y-4" aria-label="Товары каталога">
          {filtered.map((item) => (
            <article key={item.id} className={`grid gap-5 rounded-3xl border bg-[#fbf8f2] p-5 lg:grid-cols-[96px_minmax(230px,1fr)_170px_170px_170px] lg:items-center ${item.isVisible ? "border-[#d3c5b4]" : "border-dashed border-[#bbaea0] opacity-75"}`}>
              <div>
                <div className="relative h-24 overflow-hidden rounded-2xl bg-[#e7ded2]"><Image src={assetPath(item.image)} alt={`Изображение ${item.name}`} fill sizes="96px" className="object-contain p-1" /></div>
                <label className={`mt-2 flex min-h-10 cursor-pointer items-center justify-center rounded-xl border border-[#c9b9a5] bg-white px-2 text-center text-sm font-semibold text-[#60452f] ${uploadState?.id === item.id && uploadState.kind === "uploading" ? "pointer-events-none opacity-60" : ""}`}>
                  {uploadState?.id === item.id && uploadState.kind === "uploading" ? "Загружаем…" : "Заменить фото"}
                  <input type="file" accept="image/jpeg,image/png,image/webp" className="sr-only" onChange={(event) => { const file = event.target.files?.[0]; if (file) uploadImage(item, file); event.currentTarget.value = ""; }} />
                </label>
                {uploadState?.id === item.id && uploadState.kind === "saved" && <p className="mt-1 text-center text-xs font-semibold text-[#54704b]" role="status">Фото обновлено</p>}
                {uploadState?.id === item.id && uploadState.kind === "error" && <p className="mt-1 text-center text-xs text-[#9a4e39]" role="alert">{uploadState.message}</p>}
              </div>
              <div><p className="text-xs uppercase tracking-[0.14em] text-[#8f7d6c]">Модель {item.model} · {item.collection}</p><h2 className="mt-2 text-lg font-semibold">{item.name}</h2><Link href={`/product/${item.slug ?? getProductSlug(item)}`} target="_blank" className="mt-2 inline-block text-xs font-semibold text-[#71482e]">Посмотреть карточку ↗</Link></div>
              <label className="text-xs font-semibold text-[#756a5f]">Цена, ₽/м²<input value={item.pricePerSquareMeter ?? ""} onChange={(event) => update(item.id, { pricePerSquareMeter: event.target.value === "" ? undefined : Number(event.target.value) })} type="number" min="0" step="1" placeholder="По запросу" className="mt-2 min-h-11 w-full rounded-xl border border-[#c9b9a5] bg-white px-3 text-sm text-[#33291f] outline-none focus:border-[#71482e]" /></label>
              <label className="text-xs font-semibold text-[#756a5f]">Остаток, м²<input value={item.stockSquareMeters} onChange={(event) => update(item.id, { stockSquareMeters: Number(event.target.value) })} type="number" min="0" step="0.01" className="mt-2 min-h-11 w-full rounded-xl border border-[#c9b9a5] bg-white px-3 text-sm text-[#33291f] outline-none focus:border-[#71482e]" /></label>
              <div>
                <label className="flex min-h-11 cursor-pointer items-center gap-3 rounded-xl border border-[#c9b9a5] bg-white px-3 text-sm"><input checked={item.isVisible === 1} onChange={(event) => update(item.id, { isVisible: event.target.checked ? 1 : 0 })} type="checkbox" className="h-4 w-4 accent-[#71482e]" />Показывать товар</label>
                <button type="button" onClick={() => save(item)} disabled={saveState?.id === item.id && saveState.kind === "saving"} className="mt-2 min-h-11 w-full rounded-xl bg-[#71482e] px-4 text-sm font-semibold text-white disabled:opacity-60">{saveState?.id === item.id && saveState.kind === "saving" ? "Сохраняем…" : "Сохранить"}</button>
                {saveState?.id === item.id && saveState.kind === "saved" && <p className="mt-2 text-center text-xs font-semibold text-[#54704b]" role="status">Сохранено</p>}
                {saveState?.id === item.id && saveState.kind === "error" && <p className="mt-2 text-center text-xs text-[#9a4e39]" role="alert">{saveState.message}</p>}
              </div>
            </article>
          ))}
          {filtered.length === 0 && <div className="rounded-3xl border border-dashed border-[#cfc0ad] p-10 text-center text-[#756a5f]">По вашему запросу товары не найдены.</div>}
        </section>
      )}
    </div>
  );
}

function Summary({ label, value }: { label: string; value: number }) {
  return <div className="rounded-3xl bg-[#3e3228] p-5 text-[#f7efe5]"><strong className="text-3xl">{formatPrice(value)}</strong><p className="mt-1 text-xs uppercase tracking-[0.14em] text-[#cfc0b2]">{label}</p></div>;
}
