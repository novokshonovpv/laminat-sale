"use client";

import { useEffect, useState } from "react";
import { ProductCard } from "@/components/product-card";
import type { Product } from "@/data/products";

export function LiveProductCard({ product: initial }: { product: Product }) {
  const [product, setProduct] = useState<Product | null>(initial);
  useEffect(() => {
    const controller = new AbortController();
    fetch(`/api/catalog/${encodeURIComponent(initial.id)}`, { signal: controller.signal })
      .then(async response => {
        if (response.status === 404) return setProduct(null);
        if (!response.ok) throw new Error("Catalog unavailable");
        const data = await response.json();
        if (data.product) setProduct(data.product);
      }).catch(() => {});
    return () => controller.abort();
  }, [initial.id]);
  return product ? <ProductCard product={product} /> : null;
}
