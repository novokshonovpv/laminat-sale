"use client";

import { FormEvent, useEffect, useRef, useState } from "react";
import Link from "next/link";

type Item = { productId: string; packages: number };
export function CheckoutForm({ items }: { items: Item[] }) {
  const [config, setConfig] = useState<{ enabled: boolean; consentVersion: string } | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [orderId, setOrderId] = useState("");
  const pending = useRef<{ key: string; body: string } | null>(null);
  const inFlight = useRef(false);
  useEffect(() => {
    const controller = new AbortController();
    fetch("/api/checkout-config", { signal: controller.signal, cache: "no-store" })
      .then(async response => { if (!response.ok) throw new Error(); return response.json(); })
      .then(data => setConfig({ enabled: data.enabled === true && typeof data.consentVersion === "string", consentVersion: data.consentVersion || "" }))
      .catch(() => { if (!controller.signal.aborted) setError("Не удалось проверить доступность приёма заявок. Обновите страницу позже."); });
    return () => controller.abort();
  }, []);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (inFlight.current || !config?.enabled) return;
    const form = new FormData(event.currentTarget);
    const body = JSON.stringify({ name: form.get("name"), phone: form.get("phone"), comment: form.get("comment"), deliveryMethod: form.get("deliveryMethod"), website: form.get("website"), consent: form.get("consent") === "on", privacyAcknowledged: form.get("privacy") === "on", consentVersion: config.consentVersion, items });
    // After an uncertain response, retry the exact request before allowing edits.
    pending.current ??= { key: crypto.randomUUID(), body };
    inFlight.current = true; setBusy(true); setError("");
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 20000);
    try {
      const response = await fetch("/api/orders", { method: "POST", headers: { "content-type": "application/json", "idempotency-key": pending.current.key }, body: pending.current.body, signal: controller.signal });
      const data = await response.json();
      if (!response.ok) {
        if ([400, 403, 409, 413, 415, 429, 503].includes(response.status)) pending.current = null;
        throw new Error(data.error || "Не удалось сохранить заявку");
      }
      if (typeof data.orderId !== "string" || !data.orderId.startsWith("LS-")) throw new Error("Не получено подтверждение сохранения");
      setOrderId(data.orderId);
    } catch (caught) {
      setError(pending.current ? "Подтверждение не получено. Нажмите «Повторить проверку»: повторная отправка не создаст дубль. Не меняйте состав заявки до подтверждения." : caught instanceof Error ? caught.message : "Не удалось сохранить заявку");
    } finally { clearTimeout(timeout); inFlight.current = false; setBusy(false); }
  }

  if (orderId) return <div role="status" className="mt-6 rounded-2xl bg-[#e4ecde] p-5 text-[#47603f]"><h3 className="font-semibold">Заявка сохранена</h3><p className="mt-2 break-all text-sm">Номер: {orderId}</p><p className="mt-2 text-sm">Заявка доступна менеджеру в личном кабинете. Наличие, итоговая стоимость и доставка требуют подтверждения. Оплата не списывалась, товар не зарезервирован.</p></div>;
  if (!config?.enabled) return <p className="mt-6 text-sm" role="status">{error || (config ? "Приём заявок пока не включён. Данные не отправляются." : "Проверяем доступность приёма заявок…")}</p>;
  const inputClass = "mt-2 min-h-12 w-full rounded-xl border border-[#c9b9a5] bg-white px-4";
  return <form onSubmit={submit} className="mt-6">
    <fieldset disabled={busy || pending.current !== null} className="grid gap-4 sm:grid-cols-2 disabled:opacity-70">
      <label className="text-sm font-medium">Имя<input name="name" required minLength={2} maxLength={100} autoComplete="name" className={inputClass} /></label>
      <label className="text-sm font-medium">Телефон<input name="phone" type="tel" required maxLength={40} autoComplete="tel" className={inputClass} /></label>
      <label className="text-sm font-medium sm:col-span-2">Способ получения<select name="deliveryMethod" className={inputClass}><option value="pickup">Самовывоз</option><option value="delivery">Доставка — стоимость уточнит менеджер</option></select></label>
      <label className="text-sm font-medium sm:col-span-2">Комментарий<textarea name="comment" maxLength={1000} rows={3} className={`${inputClass} py-3`} placeholder="Например, удобное время для звонка" /></label>
      <div hidden aria-hidden="true"><label>Сайт<input name="website" tabIndex={-1} autoComplete="off" /></label></div>
      <label className="flex items-start gap-3 text-sm leading-6 sm:col-span-2"><input name="privacy" type="checkbox" required className="mt-1 h-4 w-4 shrink-0" /><span>Я ознакомлен(а) с <Link href="/privacy" target="_blank" className="underline">Политикой конфиденциальности и обработки персональных данных</Link>.</span></label>
      <label className="flex items-start gap-3 text-sm leading-6 sm:col-span-2"><input name="consent" type="checkbox" required className="mt-1 h-4 w-4 shrink-0" /><span>Я отдельно даю <Link href="/personal-data-consent" target="_blank" className="underline">согласие на обработку персональных данных</Link>.</span></label>
    </fieldset>
    {error && <p role="alert" className="mt-4 text-sm text-[#8b3f2c]">{error}</p>}
    <button disabled={busy} className="mt-5 rounded-full bg-[#71482e] px-7 py-3 text-sm font-semibold text-white disabled:opacity-60">{busy ? "Сохраняем…" : pending.current ? "Повторить проверку" : "Отправить заявку"}</button>
    <p className="mt-3 text-sm text-[#817469]">Без онлайн-оплаты. Цены и наличие подтвердит менеджер. Письма пока не отправляются.</p>
  </form>;
}
