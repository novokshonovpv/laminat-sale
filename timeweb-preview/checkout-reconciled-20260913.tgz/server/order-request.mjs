import { createHash, randomUUID } from 'node:crypto';

export class OrderInputError extends Error {
  constructor(message, status = 400) { super(message); this.status = status; }
}
function field(value, max, label) {
  if (typeof value !== 'string' || value.length > max) throw new OrderInputError(`Проверьте поле «${label}»`);
  return value.trim().replace(/\s+/g, ' ');
}
export function validateOrder(payload, requestKey, consentVersion) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) throw new OrderInputError('Некорректные данные');
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(requestKey || '')) throw new OrderInputError('Обновите форму заказа');
  if (payload.website) throw new OrderInputError('Заявка не принята');
  const name = field(payload.name, 100, 'Имя');
  const phone = field(payload.phone, 40, 'Телефон');
  const comment = field(payload.comment ?? '', 1000, 'Комментарий');
  if (name.length < 2) throw new OrderInputError('Укажите имя');
  if (!/^\+?[\d\s()-]+$/.test(phone) || !/^\d{10,15}$/.test(phone.replace(/\D/g, ''))) throw new OrderInputError('Проверьте телефон');
  if (!['pickup','delivery'].includes(payload.deliveryMethod)) throw new OrderInputError('Выберите способ получения');
  if (payload.consent !== true || payload.privacyAcknowledged !== true || payload.consentVersion !== consentVersion) throw new OrderInputError('Подтвердите актуальное согласие на обработку данных');
  if (!Array.isArray(payload.items) || payload.items.length < 1 || payload.items.length > 20) throw new OrderInputError('Проверьте состав корзины');
  const seen = new Set();
  const items = payload.items.map(item => {
    if (!item || typeof item !== 'object' || typeof item.productId !== 'string' || !/^[a-z0-9-]{1,100}$/.test(item.productId) || !Number.isInteger(item.packages) || item.packages < 1 || item.packages > 999 || seen.has(item.productId)) throw new OrderInputError('Проверьте товары и количество упаковок');
    seen.add(item.productId);
    return { productId: item.productId, packages: item.packages };
  }).sort((a,b) => a.productId.localeCompare(b.productId));
  return { name, phone, comment, deliveryMethod: payload.deliveryMethod, items, consentVersion };
}

// A request for manager confirmation: no payment, stock reservation, or email.
export async function saveOrderRequest(pool, payload, requestKey, { consentVersion, source }) {
  if (!consentVersion || !source) throw new Error('Checkout consent configuration missing');
  const data = validateOrder(payload, requestKey, consentVersion);
  requestKey = requestKey.toLowerCase();
  const hash = createHash('sha256').update(JSON.stringify(data)).digest('hex');
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    // Serializes duplicate submissions, including simultaneous requests.
    await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [requestKey]);
    const prior = (await client.query('SELECT id, request_hash FROM orders WHERE request_key=$1', [requestKey])).rows[0];
    if (prior) {
      if (prior.request_hash !== hash) throw new OrderInputError('Эта заявка уже отправлена с другим составом', 409);
      await client.query('COMMIT');
      return { orderId: prior.id, notificationStatus: 'not_configured', repeated: true };
    }
    const products = (await client.query('SELECT * FROM products WHERE id = ANY($1::text[]) AND is_visible=1 ORDER BY id FOR SHARE', [data.items.map(item => item.productId)])).rows;
    const lines = data.items.map(item => {
      const product = products.find(p => p.id === item.productId);
      if (!product) throw new OrderInputError('Один из товаров больше недоступен. Обновите корзину.', 409);
      const packageArea = Number(product.package_area);
      const price = product.price_per_square_meter == null ? null : Number(product.price_per_square_meter);
      if (!Number.isFinite(packageArea) || packageArea <= 0 || (price !== null && (!Number.isInteger(price) || price < 0))) throw new OrderInputError('Параметры товара требуют уточнения', 409);
      const area = Math.round(packageArea * item.packages * 100) / 100;
      return { ...item, model: product.model, name: product.name, packageArea, area, pricePerSquareMeter: price, subtotal: price === null ? null : Math.round(area * price) };
    });
    const totalArea = Math.round(lines.reduce((sum,item) => sum + item.area, 0)*100)/100;
    const hasRequestPrice = lines.some(item => item.subtotal === null);
    const totalPrice = hasRequestPrice ? null : lines.reduce((sum,item) => sum + item.subtotal, 0);
    if (!Number.isFinite(totalArea) || totalArea <= 0 || lines.some(item => item.subtotal !== null && !Number.isSafeInteger(item.subtotal)) || (totalPrice !== null && !Number.isSafeInteger(totalPrice))) throw new OrderInputError('Сумма требует уточнения', 409);
    const id = `LS-${randomUUID()}`;
    await client.query('INSERT INTO orders (id,request_key,request_hash,customer_name,customer_phone,comment,delivery_method,item_count,total_area,total_price,has_request_price,items_json,consent_version,consent_source) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)', [id,requestKey,hash,data.name,data.phone,data.comment,data.deliveryMethod,lines.length,totalArea,totalPrice,hasRequestPrice?1:0,JSON.stringify(lines),consentVersion,source]);
    for (const item of lines) await client.query('INSERT INTO order_items (order_id,product_id,model,name,packages,package_area,area,price_per_square_meter,subtotal) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)', [id,item.productId,item.model,item.name,item.packages,item.packageArea,item.area,item.pricePerSquareMeter,item.subtotal]);
    await client.query('COMMIT');
    return { orderId: id, notificationStatus: 'not_configured', repeated: false };
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally { client.release(); }
}
