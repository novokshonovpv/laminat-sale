import http from 'node:http';
import { readFile, writeFile, mkdir, unlink, realpath } from 'node:fs/promises';
import path from 'node:path';
import { createHash, timingSafeEqual, webcrypto } from 'node:crypto';
import { Readable } from 'node:stream';
import pg from 'pg';
import worker from '../sites-worker.mjs';
import { publicResource } from './access-policy.mjs';
import { saveOrderRequest, OrderInputError } from './order-request.mjs';

globalThis.crypto ??= webcrypto;
pg.types.setTypeParser(1700, Number);
pg.types.setTypeParser(1114, value => value);
const pool = new pg.Pool({ host: '/var/run/postgresql', database: 'laminat_sale', user: 'laminat', max: 5 });
const staticRoot = await realpath(process.env.STATIC_ROOT || new URL('../out', import.meta.url).pathname);
const uploadRoot = path.resolve(process.env.UPLOAD_ROOT || '/opt/laminat-sale/uploads');
await mkdir(uploadRoot, { recursive: true });
const password = process.env.ADMIN_PASSWORD;
if (!password || password.length < 24) throw new Error('ADMIN_PASSWORD must contain at least 24 characters');
const expectedAuth = createHash('sha256').update(`Basic ${Buffer.from(`owner:${password}`).toString('base64')}`).digest();
const checkoutEnabled = process.env.CHECKOUT_ENABLED === 'true';
const consentVersion = process.env.CHECKOUT_CONSENT_VERSION || '';
if (checkoutEnabled && !consentVersion) throw new Error('Checkout consent version is required');
const requestWindows = new Map();
function checkoutRateAllowed(address) {
  const now = Date.now();
  for (const [key, value] of requestWindows) if (value.until <= now) requestWindows.delete(key);
  const window = requestWindows.get(address) || { until: now + 60000, count: 0 };
  if (requestWindows.size >= 10000 && !requestWindows.has(address)) return false;
  requestWindows.set(address, window);
  return ++window.count <= 10;
}
function jsonReply(outgoing, status, data) {
  outgoing.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-robots-tag': 'noindex, nofollow' });
  outgoing.end(JSON.stringify(data));
}

// The existing Worker contains only fixed SQL. Bind values remain parameters.
function sqlForPostgres(sql) {
  let index = 0;
  return sql.replace('CASE WHEN ? IS NOT NULL', 'CASE WHEN CAST(? as integer) IS NOT NULL')
    .replace(/\?/g, () => `$${++index}`)
    .replace(/\bAS\s+([A-Za-z][A-Za-z0-9_]*)/g, 'AS "$1"')
    .replace(/ COLLATE NOCASE/g, '');
}
function statement(sql, values = []) {
  const query = async client => client.query(sqlForPostgres(sql), values);
  return {
    bind: (...args) => statement(sql, args),
    first: async () => (await query(pool)).rows[0] ?? null,
    all: async () => ({ results: (await query(pool)).rows }),
    run: async () => ({ meta: { changes: (await query(pool)).rowCount } }),
    query,
  };
}
const DB = {
  prepare: statement,
  async batch(statements) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const results = [];
      for (const stmt of statements) {
        const result = await stmt.query(client);
        results.push({ results: result.rows, meta: { changes: result.rowCount } });
      }
      await client.query('COMMIT');
      return results;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally { client.release(); }
  },
};
function imagePath(key) {
  if (!/^products\/[a-z0-9-]+\.(jpg|png|webp)$/.test(key)) throw new Error('Invalid image key');
  return path.join(uploadRoot, key);
}
const PRODUCT_IMAGES = {
  async put(key, data) {
    const file = imagePath(key);
    await mkdir(path.dirname(file), { recursive: true });
    await writeFile(file, Buffer.from(data), { flag: 'wx', mode: 0o640 });
  },
  async delete(key) { await unlink(imagePath(key)); },
  async get(key) {
    try {
      const bytes = await readFile(imagePath(key));
      return { body: bytes, httpMetadata: { contentType: key.endsWith('.jpg') ? 'image/jpeg' : key.endsWith('.png') ? 'image/png' : 'image/webp' }, httpEtag: `"${createHash('sha256').update(bytes).digest('hex')}"` };
    } catch (error) { if (error.code === 'ENOENT') return null; throw error; }
  },
};
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.txt': 'text/plain; charset=utf-8', '.jpg': 'image/jpeg', '.png': 'image/png', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.xml': 'application/xml' };
const ASSETS = {
  async fetch(request) {
    let relative;
    try { relative = decodeURIComponent(new URL(request.url).pathname); } catch { return new Response(null, { status: 400 }); }
    if (relative.endsWith('/')) relative += 'index.html';
    try {
      const file = await realpath(path.resolve(staticRoot, '.' + relative));
      if (!file.startsWith(staticRoot + path.sep)) return new Response(null, { status: 404 });
      const bytes = await readFile(file);
      return new Response(bytes, { headers: { 'content-type': mime[path.extname(file)] || 'application/octet-stream', 'x-content-type-options': 'nosniff' } });
    } catch (error) {
      if (['ENOENT', 'EISDIR', 'ENOTDIR'].includes(error.code)) return new Response(null, { status: 404 });
      throw error;
    }
  },
};
const server = http.createServer(async (incoming, outgoing) => {
  try {
    const host = incoming.headers.host;
    if (!host || !/^[a-zA-Z0-9.\-:\[\]]+$/.test(host)) { outgoing.writeHead(400); return outgoing.end(); }
    const url = new URL(incoming.url, `http://${host}`);
    const provided = createHash('sha256').update(incoming.headers.authorization || '').digest();
    const authenticated = timingSafeEqual(provided, expectedAuth);
    const resource = publicResource(incoming.method, url.pathname, process.env.PUBLIC_STOREFRONT === 'true');
    const publicCheckout = process.env.PUBLIC_STOREFRONT === 'true' && (url.pathname === '/api/checkout-config' && incoming.method === 'GET' || url.pathname === '/api/orders' && incoming.method === 'POST');
    if (!authenticated && !resource && !publicCheckout) {
      outgoing.writeHead(401, { 'www-authenticate': 'Basic realm="Laminat preview", charset="UTF-8"', 'cache-control': 'no-store' });
      return outgoing.end('Требуется вход владельца');
    }
    // Exported HTML/RSC aliases must not reveal hidden products.
    if (resource?.kind === 'product') {
      const visible = await pool.query('SELECT 1 FROM products WHERE slug = $1 AND is_visible = 1', [resource.slug]);
      if (!visible.rowCount) { outgoing.writeHead(404); return outgoing.end('Товар не найден'); }
    }
    if (!['GET', 'HEAD'].includes(incoming.method) && (incoming.headers['sec-fetch-site'] === 'cross-site' || (incoming.headers.origin && incoming.headers.origin !== url.origin))) {
      outgoing.writeHead(403); return outgoing.end('Недопустимый источник запроса');
    }
    if (url.pathname === '/api/checkout-config' && incoming.method === 'GET') {
      return jsonReply(outgoing, 200, { enabled: checkoutEnabled, consentVersion: checkoutEnabled ? consentVersion : null });
    }
    if (url.pathname === '/api/orders' || url.pathname.startsWith('/api/admin/orders')) {
      if (!checkoutEnabled || url.pathname.endsWith('/notify')) return jsonReply(outgoing, 503, { error: 'Приём заявок или уведомления пока не подключены' });
    }
    if (url.pathname === '/api/orders') {
      if (incoming.method !== 'POST') return jsonReply(outgoing, 405, { error: 'Метод не поддерживается' });
      if (incoming.headers.origin !== url.origin) return jsonReply(outgoing, 403, { error: 'Отправьте заявку через форму сайта' });
      if (!/^application\/json(?:;|$)/i.test(incoming.headers['content-type'] || '')) return jsonReply(outgoing, 415, { error: 'Ожидается JSON' });
      // Nginx overwrites X-Real-IP; this process listens on loopback only.
      if (!checkoutRateAllowed(incoming.headers['x-real-ip'] || incoming.socket.remoteAddress)) return jsonReply(outgoing, 429, { error: 'Слишком много попыток. Повторите через минуту.' });
      const parts = []; let bytes = 0;
      for await (const part of incoming) {
        bytes += part.length;
        if (bytes > 30000) return jsonReply(outgoing, 413, { error: 'Слишком большой запрос' });
        parts.push(part);
      }
      let payload;
      try { payload = JSON.parse(Buffer.concat(parts).toString('utf8')); }
      catch { return jsonReply(outgoing, 400, { error: 'Некорректные данные' }); }
      const result = await saveOrderRequest(pool, payload, incoming.headers['idempotency-key'], { consentVersion, source: 'https://preview.laminat.sale/cart/' });
      return jsonReply(outgoing, result.repeated ? 200 : 201, result);
    }
    const chunks = []; let size = 0;
    for await (const chunk of incoming) {
      size += chunk.length;
      if (size > 8_500_000) { outgoing.writeHead(413); return outgoing.end('Файл слишком большой'); }
      chunks.push(chunk);
    }
    const headers = new Headers();
    for (const [key, value] of Object.entries(incoming.headers)) {
      if (!key.startsWith('oai-') && !['authorization', 'host', 'connection', 'transfer-encoding'].includes(key) && typeof value === 'string') headers.set(key, value);
    }
    if (authenticated) headers.set('oai-authenticated-user-id', 'timeweb-owner');
    const request = new Request(url, { method: incoming.method, headers, body: ['GET', 'HEAD'].includes(incoming.method) ? undefined : Buffer.concat(chunks) });
    const response = await worker.fetch(request, { DB, PRODUCT_IMAGES, ASSETS, ADMIN_USER_ID: 'timeweb-owner' });
    outgoing.writeHead(response.status, { ...Object.fromEntries(response.headers), 'cache-control': 'no-store', 'x-robots-tag': 'noindex, nofollow' });
    if (incoming.method === 'HEAD' || !response.body) outgoing.end();
    else Readable.fromWeb(response.body).pipe(outgoing);
  } catch (error) {
    if (error instanceof OrderInputError) return jsonReply(outgoing, error.status, { error: error.message });
    // Do not log query details that can contain customer data.
    console.error('Request failed', error.code || error.name);
    if (!outgoing.headersSent) outgoing.writeHead(500, { 'content-type': 'application/json; charset=utf-8' });
    outgoing.end(JSON.stringify({ error: 'Сервис временно недоступен' }));
  }
});
server.requestTimeout = 30000;
const port = Number(process.env.PORT || 3080);
if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('Invalid port');
server.listen(port, '127.0.0.1', () => console.log(`Catalog listening on 127.0.0.1:${port}`));
