// Public access is opt-in; unknown routes and every mutation stay protected.
export function publicResource(method, pathname, enabled = false) {
  if (!enabled || !['GET', 'HEAD'].includes(method)) return null;
  if (pathname.includes('%') || pathname.includes('\\') || pathname.includes('//')) return null;
  if (pathname.split('/').some(part => part === '.' || part === '..')) return null;
  pathname = pathname.replace(/\/(?:index\.(?:html|txt)|__next\.[a-z_.]+\.txt)$/, '/');
  if (/^\/api\/catalog(?:\/[a-z0-9-]+)?\/?$/.test(pathname)) return { kind: 'catalog' };
  if (/^\/(?:index(?:\.html|\.txt)?|(?:catalog|cart|cookies|privacy|personal-data-consent)(?:\/index\.html|\.html|\.txt|\/)?)?$/.test(pathname)) return { kind: 'page' };
  const product = pathname.match(/^\/product\/([a-z0-9-]+)(?:\/index\.html|\.html|\.txt|\/)?$/);
  if (product) return { kind: 'product', slug: product[1] };
  if (/^\/_next\/static\/[a-zA-Z0-9_./()\[\]-]+\.(?:js|css|woff2?)$/.test(pathname)) return { kind: 'asset' };
  if (/^\/(?:media\/)?products\/[a-z0-9-]+\.(?:jpg|png|webp)$/.test(pathname)) return { kind: 'asset' };
  if (['/favicon.ico', '/spc-structure-ru.png', '/spc-structure-ru.jpg', '/spc-technical-sheet.jpg', '/robots.txt', '/sitemap.xml'].includes(pathname)) return { kind: 'asset' };
  return null;
}
