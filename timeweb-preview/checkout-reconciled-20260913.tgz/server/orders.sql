-- Apply once as database owner before enabling checkout. No existing data removed.
BEGIN;
CREATE TABLE IF NOT EXISTS orders (
  id text PRIMARY KEY,
  request_key uuid NOT NULL UNIQUE,
  request_hash text NOT NULL,
  customer_name text NOT NULL,
  customer_phone text NOT NULL,
  customer_email text,
  comment text,
  delivery_method text NOT NULL CHECK (delivery_method IN ('pickup', 'delivery')),
  status text NOT NULL DEFAULT 'new' CHECK (status IN ('new','confirmed','completed','cancelled')),
  item_count integer NOT NULL CHECK (item_count BETWEEN 1 AND 20),
  total_area numeric NOT NULL CHECK (total_area > 0),
  total_price bigint,
  has_request_price integer NOT NULL,
  items_json text NOT NULL,
  consent_version text NOT NULL,
  consent_source text NOT NULL,
  consent_at timestamp NOT NULL DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
  notification_status text NOT NULL DEFAULT 'not_configured',
  notification_error text,
  notification_id text,
  created_at timestamp NOT NULL DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'),
  updated_at timestamp NOT NULL DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC')
);
CREATE INDEX IF NOT EXISTS orders_created_at_idx ON orders(created_at DESC);
CREATE TABLE IF NOT EXISTS order_items (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  order_id text NOT NULL REFERENCES orders(id),
  product_id text NOT NULL,
  model text NOT NULL,
  name text NOT NULL,
  packages integer NOT NULL CHECK (packages BETWEEN 1 AND 999),
  package_area numeric NOT NULL,
  area numeric NOT NULL,
  price_per_square_meter integer,
  subtotal bigint,
  UNIQUE(order_id, product_id)
);
COMMIT;
