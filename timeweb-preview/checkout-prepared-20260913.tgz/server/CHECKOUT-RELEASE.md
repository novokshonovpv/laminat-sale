# Checkout release — NOT DEPLOYED

Prepared 2026-09-13. The live Timeweb deployment is unchanged.

Local changes: CheckoutForm uses /api/checkout-config and POST /api/orders;
success requires persisted order ID. Idempotency key and exact body survive
uncertain responses in memory (not browser storage); reloading loses this retry
context. Owner order status mutations report failures and release busy state.
Email retries are hidden when email is unconfigured. No payment or stock reservation.

CHECKOUT_ENABLED is false by default. Never enable it merely to make the UI show.
Before activation:

1. Restore a working transfer channel to the existing Timeweb server. SSH on
   2026-09-13 still closed before authentication. Browser console is available;
   no support message was sent and DNS was not changed.
2. Take and verify a fresh backup. Inspect the actual PostgreSQL tables before
   applying orders.sql; IF NOT EXISTS does not upgrade an incompatible schema.
3. Apply schema as the laminat role to an isolated test DB first, and test real
   PostgreSQL duplicate/concurrent submits, rollback, hidden products, owner
   listing and status changes. Current tests use a mock DB, not PostgreSQL.
4. Confirm actual database location and processor details with the operator.
   Dashboard configuration says Cloud MSK 50; do not infer legal compliance.
   Review the updated disclosure drafts before collection. Archive the exact
   privacy/consent pages with the release and assign CHECKOUT_CONSENT_VERSION
   to that immutable revision. Do not silently reuse a version for changed text.
5. Stage matching out/, sites-worker.mjs and server/ together, leaving
   CHECKOUT_ENABLED=false; preserve existing env/password, uploads and DB.
   Install pg using existing lockfile. Keep previous release for rollback.
6. Verify anonymous admin routes stay 401, config says disabled and orders 503;
   check form visually on desktop/mobile. Then enable only for the approved
   preview audience and verify a synthetic request end-to-end and clean up
   only its exact generated order ID in the test environment.
7. Enable real collection only after these checks. Keep email and YooKassa off.

The existing server smoke.mjs expects checkout disabled; it is a catalog test,
not evidence that enabled checkout works. The backup pg_dump includes new tables
automatically, but off-server backup remains explicitly deferred by the user.
